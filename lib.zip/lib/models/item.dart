class Item {
  final int? id;
  final String name;
  final String? productCode;
  final int quantity;
  final double costPrice;
  final double sellingPrice;

  Item({
    this.id,
    required this.name,
    this.productCode,
    required this.quantity,
    required this.costPrice,
    required this.sellingPrice,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'productCode': productCode,
      'quantity': quantity,
      'costPrice': costPrice,
      'sellingPrice': sellingPrice,
    };
  }

  factory Item.fromJson(Map<String, dynamic> json) {
    return Item(
      id: json['id'] as int?,
      name: json['name'] as String,
      productCode: json['productCode'] as String?,
      quantity: json['quantity'] as int,
      costPrice: json['costPrice'] as double,
      sellingPrice: json['sellingPrice'] as double,
    );
  }
}
