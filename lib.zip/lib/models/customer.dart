class Customer {
  final int? id;
  final String name;
  final String? contactNumber;

  Customer({
    this.id,
    required this.name,
    this.contactNumber,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'contactNumber': contactNumber,
    };
  }

  factory Customer.fromJson(Map<String, dynamic> json) {
    return Customer(
      id: json['id'] as int?,
      name: json['name'] as String,
      contactNumber: json['contactNumber'] as String?,
    );
  }
}
