class Invoice {
  final int? id;
  final int customerId;
  final DateTime date;
  final double subtotal;
  final double discount;
  final double totalAmount;
  final String paymentStatus;

  Invoice({
    this.id,
    required this.customerId,
    required this.date,
    required this.subtotal,
    required this.discount,
    required this.totalAmount,
    required this.paymentStatus,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'customerId': customerId,
      'date': date.toIso8601String(),
      'subtotal': subtotal,
      'discount': discount,
      'totalAmount': totalAmount,
      'paymentStatus': paymentStatus,
    };
  }

  factory Invoice.fromJson(Map<String, dynamic> json) {
    return Invoice(
      id: json['id'] as int?,
      customerId: json['customerId'] as int,
      date: DateTime.parse(json['date'] as String),
      subtotal: json['subtotal'] as double,
      discount: json['discount'] as double,
      totalAmount: json['totalAmount'] as double,
      paymentStatus: json['paymentStatus'] as String,
    );
  }
}
