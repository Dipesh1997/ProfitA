import 'package:flutter/material.dart';

class VoiceCommandHandler {
  static void handleCommand(String command, BuildContext context) {
    if (command.contains('add item') || command.contains('new item')) {
      Navigator.pushNamed(context, '/items');
      // Trigger add item dialog
    } else if (command.contains('add customer')) {
      Navigator.pushNamed(context, '/customers');
      // Trigger add customer dialog
    } else if (command.contains('create invoice')) {
      Navigator.pushNamed(context, '/invoices');
      // Trigger create invoice dialog
    }
    // Add more commands...
  }
}
