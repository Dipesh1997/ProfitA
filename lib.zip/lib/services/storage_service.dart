import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

class StorageService {
  static Future<String> get _localPath async {
    final directory = await getApplicationDocumentsDirectory();
    return directory.path;
  }

  static Future<File> get _itemsFile async {
    final path = await _localPath;
    return File('$path/items.json');
  }

  static Future<List<Map<String, dynamic>>> loadItems() async {
    try {
      final file = await _itemsFile;
      if (!await file.exists()) {
        return [];
      }
      final contents = await file.readAsString();
      final List<dynamic> jsonList = json.decode(contents);
      return jsonList.cast<Map<String, dynamic>>();
    } catch (e) {
      print('Error loading items: $e');
      return [];
    }
  }

  static Future<void> saveItems(List<Map<String, dynamic>> items) async {
    try {
      final file = await _itemsFile;
      final jsonString = json.encode(items);
      await file.writeAsString(jsonString);
    } catch (e) {
      print('Error saving items: $e');
    }
  }
} 