import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:excel/excel.dart';
import 'database_helper.dart';

class ExportService {
  static Future<String> exportToExcel() async {
    final excel = Excel.createExcel();

    // Add Items Sheet
    final itemsSheet = excel['Items'];
    final items = await DatabaseHelper.instance.getAllItems();
    // Add headers
    itemsSheet.appendRow([
      TextCellValue('ID'),
      TextCellValue('Name'),
      TextCellValue('Code'),
      TextCellValue('Quantity'),
      TextCellValue('Cost'),
      TextCellValue('Price'),
    ]);
    // Add data
    for (var item in items) {
      itemsSheet.appendRow([
        TextCellValue(item.id?.toString() ?? ''),
        TextCellValue(item.name),
        TextCellValue(item.productCode ?? ''),
        TextCellValue(item.quantity.toString()),
        TextCellValue(item.costPrice.toString()),
        TextCellValue(item.sellingPrice.toString()),
      ]);
    }

    // Add Customers Sheet
    // Add Invoices Sheet
    // ... similar implementation for other data

    // Save file
    final dir = await getApplicationDocumentsDirectory();
    final dateStr = DateTime.now().toString().split(' ')[0];
    final file = File('${dir.path}/profit_export_$dateStr.xlsx');

    await file.writeAsBytes(excel.encode()!);
    return file.path;
  }
}
