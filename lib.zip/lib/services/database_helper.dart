import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/item.dart';
import '../models/customer.dart';
import '../models/invoice.dart';
import '../pages/invoices_page.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('profit.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    try {
      final dbPath = await getDatabasesPath();
      final path = join(dbPath, filePath);

      return await openDatabase(
        path,
        version: 2, // Increment version number
        onCreate: _createDB,
      );
    } catch (e) {
      throw Exception('Failed to initialize database: $e');
    }
  }

  Future<void> _createDB(Database db, int version) async {
    try {
      // Create all tables in order
      await db.execute('''
        CREATE TABLE items(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          productCode TEXT,
          quantity INTEGER NOT NULL,
          costPrice REAL NOT NULL,
          sellingPrice REAL NOT NULL,
          category TEXT,
          description TEXT
        )
      ''');

      await db.execute('''
        CREATE TABLE customers(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          name TEXT NOT NULL,
          contactNumber TEXT,
          email TEXT,
          address TEXT,
          totalPurchases REAL DEFAULT 0,
          lastPurchaseDate TEXT
        )
      ''');

      await db.execute('''
        CREATE TABLE invoices(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          customerId INTEGER NOT NULL,
          date TEXT NOT NULL,
          subtotal REAL NOT NULL,
          discount REAL NOT NULL DEFAULT 0,
          totalAmount REAL NOT NULL,
          paymentStatus TEXT NOT NULL DEFAULT 'PENDING',
          FOREIGN KEY (customerId) REFERENCES customers (id)
        )
      ''');

      await db.execute('''
        CREATE TABLE invoice_items(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          invoiceId INTEGER NOT NULL,
          itemId INTEGER NOT NULL,
          quantity INTEGER NOT NULL,
          price REAL NOT NULL,
          total REAL NOT NULL,
          FOREIGN KEY (invoiceId) REFERENCES invoices (id) ON DELETE CASCADE,
          FOREIGN KEY (itemId) REFERENCES items (id)
        )
      ''');
    } catch (e) {
      throw Exception('Failed to create tables: $e');
    }
  }

  Future<List<Item>> getAllItems() async {
    try {
      final db = await database;
      final result = await db.query('items', orderBy: 'name ASC');
      return result.map((json) => Item.fromJson(json)).toList();
    } catch (e) {
      throw Exception('Failed to get items: $e');
    }
  }

  Future<int> insertItem(Item item) async {
    final db = await database;
    return await db.insert('items', item.toJson());
  }

  Future<int> updateItem(Item item) async {
    final db = await database;
    return await db.update(
      'items',
      item.toJson(),
      where: 'id = ?',
      whereArgs: [item.id],
    );
  }

  Future<int> deleteItem(int id) async {
    final db = await database;
    return await db.delete(
      'items',
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<List<Customer>> getAllCustomers() async {
    try {
      final db = await database;
      final result = await db.query('customers', orderBy: 'name ASC');
      return result.map((json) => Customer.fromJson(json)).toList();
    } catch (e) {
      throw Exception('Failed to get customers: $e');
    }
  }

  Future<int> insertCustomer(Customer customer) async {
    try {
      final db = await database;
      final data = customer.toJson();
      data.remove('id');
      return await db.insert('customers', data);
    } catch (e) {
      throw Exception('Failed to add customer: $e');
    }
  }

  Future<int> deleteCustomer(int id) async {
    try {
      final db = await database;
      return await db.delete(
        'customers',
        where: 'id = ?',
        whereArgs: [id],
      );
    } catch (e) {
      throw Exception('Failed to delete customer: $e');
    }
  }

  Future<List<Invoice>> getAllInvoices() async {
    try {
      final db = await database;
      final result = await db.query('invoices', orderBy: 'date DESC');
      return result.map((json) => Invoice.fromJson(json)).toList();
    } catch (e) {
      throw Exception('Failed to get invoices: $e');
    }
  }

  Future<int> insertInvoice(Invoice invoice, List<InvoiceItem> items) async {
    final db = await database;

    try {
      return await db.transaction((txn) async {
        // Insert invoice
        final invoiceData = {
          'customerId': invoice.customerId,
          'date': invoice.date.toIso8601String(),
          'subtotal': invoice.subtotal,
          'discount': invoice.discount,
          'totalAmount': invoice.totalAmount,
          'paymentStatus': invoice.paymentStatus,
        };

        final invoiceId = await txn.insert('invoices', invoiceData);

        // Insert invoice items
        for (var item in items) {
          await txn.insert('invoice_items', {
            'invoiceId': invoiceId,
            'itemId': item.item.id,
            'quantity': item.quantity,
            'price': item.price,
            'total': item.total,
          });
        }

        return invoiceId;
      });
    } catch (e) {
      throw Exception('Failed to save invoice: $e');
    }
  }

  Future<int> deleteInvoice(int id) async {
    try {
      final db = await database;
      return await db.delete(
        'invoices',
        where: 'id = ?',
        whereArgs: [id],
      );
    } catch (e) {
      throw Exception('Failed to delete invoice: $e');
    }
  }

  Future<void> close() async {
    final db = await database;
    db.close();
  }
}
