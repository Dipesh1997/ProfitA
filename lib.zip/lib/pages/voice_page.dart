import 'package:flutter/material.dart';
import '../services/voice_service.dart';
import '../services/voice_command_handler.dart';

class VoicePage extends StatefulWidget {
  const VoicePage({super.key});

  @override
  State<VoicePage> createState() => _VoicePageState();
}

class _VoicePageState extends State<VoicePage> {
  final VoiceService _voiceService = VoiceService();
  String _lastCommand = '';
  bool _isListening = false;

  void _toggleListening() {
    if (_isListening) {
      _voiceService.stopListening();
    } else {
      _voiceService.startListening((command) {
        setState(() => _lastCommand = command);
        VoiceCommandHandler.handleCommand(command, context);
      });
    }
    setState(() => _isListening = !_isListening);
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            _isListening ? Icons.mic : Icons.mic_none,
            size: 100,
            color: _isListening ? Colors.red : Colors.grey,
          ),
          const SizedBox(height: 20),
          Text(
            _isListening ? 'Listening...' : 'Tap to start',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          if (_lastCommand.isNotEmpty)
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                'Last command: $_lastCommand',
                style: Theme.of(context).textTheme.bodyLarge,
              ),
            ),
          ElevatedButton.icon(
            onPressed: _toggleListening,
            icon: Icon(_isListening ? Icons.stop : Icons.play_arrow),
            label: Text(_isListening ? 'Stop' : 'Start'),
          ),
        ],
      ),
    );
  }
}
