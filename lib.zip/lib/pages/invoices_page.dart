import 'package:flutter/material.dart';
import '../models/invoice.dart';
import '../models/customer.dart';
import '../models/item.dart';
import '../services/database_helper.dart';

class InvoiceItem {
  final Item item;
  int quantity;
  double price;

  InvoiceItem({
    required this.item,
    this.quantity = 1,
    required this.price,
  });

  double get total => quantity * price;
}

class InvoicesPage extends StatefulWidget {
  const InvoicesPage({super.key});

  @override
  State<InvoicesPage> createState() => _InvoicesPageState();
}

class _InvoicesPageState extends State<InvoicesPage> {
  List<Invoice> _invoices = [];
  List<Customer> _customers = [];
  List<Item> _items = [];
  bool _isLoading = false;
  final List<InvoiceItem> _selectedItems = [];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    try {
      final customers = await DatabaseHelper.instance.getAllCustomers();
      final items = await DatabaseHelper.instance.getAllItems();
      final invoices = await DatabaseHelper.instance.getAllInvoices();

      setState(() {
        _customers = customers;
        _items = items;
        _invoices = invoices;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      _showErrorDialog('Failed to load data');
    }
  }

  void _showCreateInvoiceDialog() {
    if (_customers.isEmpty || _items.isEmpty) {
      _showErrorDialog('Please add customers and items first');
      return;
    }

    Customer? selectedCustomer = _customers.first;
    _selectedItems.clear();

    final discountController = TextEditingController(text: '0');

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: const Text('Create New Invoice'),
          contentPadding: const EdgeInsets.fromLTRB(24, 20, 24, 0),
          content: SizedBox(
            width: MediaQuery.of(context).size.width * 0.9,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Customer Dropdown
                  DropdownButtonFormField<Customer>(
                    value: selectedCustomer,
                    decoration:
                        const InputDecoration(labelText: 'Select Customer'),
                    items: _customers.map((customer) {
                      return DropdownMenuItem(
                        value: customer,
                        child: Text(customer.name),
                      );
                    }).toList(),
                    onChanged: (value) =>
                        setState(() => selectedCustomer = value),
                  ),
                  const SizedBox(height: 16),

                  // Selected Items List
                  ..._selectedItems
                      .map((invoiceItem) => Card(
                            margin: const EdgeInsets.symmetric(vertical: 4),
                            child: Padding(
                              padding: const EdgeInsets.all(8),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Expanded(
                                        child: Text(
                                          invoiceItem.item.name,
                                          style: const TextStyle(
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                      IconButton(
                                        icon: const Icon(Icons.delete,
                                            color: Colors.red, size: 20),
                                        padding: EdgeInsets.zero,
                                        constraints: const BoxConstraints(),
                                        onPressed: () => setState(() {
                                          _selectedItems.remove(invoiceItem);
                                        }),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 8),
                                  Row(
                                    children: [
                                      SizedBox(
                                        width: 80,
                                        child: TextFormField(
                                          initialValue:
                                              invoiceItem.quantity.toString(),
                                          decoration: const InputDecoration(
                                            labelText: 'Qty',
                                            isDense: true,
                                            contentPadding:
                                                EdgeInsets.symmetric(
                                              horizontal: 8,
                                              vertical: 8,
                                            ),
                                          ),
                                          keyboardType: TextInputType.number,
                                          onChanged: (value) {
                                            setState(() {
                                              invoiceItem.quantity =
                                                  int.tryParse(value) ?? 1;
                                            });
                                          },
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Text(
                                          '× ₹${invoiceItem.price.toStringAsFixed(2)}'),
                                      const Spacer(),
                                      Text(
                                        '= ₹${invoiceItem.total.toStringAsFixed(2)}',
                                        style: const TextStyle(
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ))
                      .toList(),

                  // Add Item Button
                  OutlinedButton.icon(
                    onPressed: () => _showAddItemDialog(setState),
                    icon: const Icon(Icons.add),
                    label: const Text('Add Item'),
                  ),

                  const SizedBox(height: 16),
                  TextFormField(
                    controller: discountController,
                    decoration: const InputDecoration(
                      labelText: 'Discount Amount (₹)',
                      border: OutlineInputBorder(),
                    ),
                    keyboardType: TextInputType.number,
                    onChanged: (value) => setState(() {}),
                  ),
                  const SizedBox(height: 16),
                  _buildTotalSection(discountController),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: _selectedItems.isEmpty
                  ? null
                  : () => _saveInvoice(selectedCustomer!, discountController),
              child: const Text('Create Invoice'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTotalSection(TextEditingController discountController) {
    final subtotal = _calculateTotal();
    final discount = double.tryParse(discountController.text) ?? 0;
    final total = subtotal - discount;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Subtotal: ₹${subtotal.toStringAsFixed(2)}'),
        Text('Discount: ₹${discount.toStringAsFixed(2)}'),
        const SizedBox(height: 8),
        Text(
          'Total: ₹${total.toStringAsFixed(2)}',
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  void _showAddItemDialog(StateSetter parentSetState) {
    Item? selectedItem = _items.firstWhere(
      (item) => !_selectedItems.any((selected) => selected.item.id == item.id),
      orElse: () => _items.first,
    );

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add Item'),
        content: DropdownButtonFormField<Item>(
          value: selectedItem,
          decoration: const InputDecoration(labelText: 'Select Item'),
          items: _items
              .where((item) => !_selectedItems
                  .any((selected) => selected.item.id == item.id))
              .map((item) {
            return DropdownMenuItem(
              value: item,
              child: Text('${item.name} (₹${item.sellingPrice})'),
            );
          }).toList(),
          onChanged: (value) => selectedItem = value,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              if (selectedItem != null) {
                parentSetState(() {
                  _selectedItems.add(InvoiceItem(
                    item: selectedItem!,
                    price: selectedItem!.sellingPrice,
                  ));
                });
                Navigator.pop(context);
              }
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }

  double _calculateTotal() {
    return _selectedItems.fold(0, (sum, item) => sum + item.total);
  }

  Future<void> _saveInvoice(
      Customer customer, TextEditingController discountController) async {
    try {
      final subtotal = _calculateTotal();
      final discount = double.tryParse(discountController.text) ?? 0;
      final total = subtotal - discount;

      final invoice = Invoice(
        customerId: customer.id!,
        date: DateTime.now(),
        subtotal: subtotal,
        discount: discount,
        totalAmount: total,
        paymentStatus: 'PENDING',
      );

      await DatabaseHelper.instance.insertInvoice(invoice, _selectedItems);
      await _loadData();
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Invoice created successfully')),
        );
      }
    } catch (e) {
      _showErrorDialog('Failed to save invoice: ${e.toString()}');
    }
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Error'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Invoices'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _invoices.isEmpty
              ? const Center(child: Text('No invoices yet'))
              : ListView.builder(
                  itemCount: _invoices.length,
                  itemBuilder: (context, index) {
                    final invoice = _invoices[index];
                    return ListTile(
                      title: Text('Invoice #${invoice.id}'),
                      subtitle: Text('Total: ₹${invoice.totalAmount}'),
                      trailing: Text(invoice.date.toString().split(' ')[0]),
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showCreateInvoiceDialog,
        child: const Icon(Icons.add),
      ),
    );
  }
}
