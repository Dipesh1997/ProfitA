import 'package:flutter/material.dart';
import 'items_page.dart';
import '../services/database_helper.dart';
import '../pages/customers_page.dart';
import '../pages/invoices_page.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  int totalItems = 0;
  int totalCustomers = 0;
  int totalInvoices = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _loadTotalItems();
    _loadTotalCustomers();
    _loadTotalInvoices();
  }

  Future<void> _loadTotalItems() async {
    final items = await DatabaseHelper.instance.getAllItems();
    setState(() {
      totalItems = items.length;
    });
  }

  Future<void> _loadTotalCustomers() async {
    final customers = await DatabaseHelper.instance.getAllCustomers();
    setState(() {
      totalCustomers = customers.length;
    });
  }

  Future<void> _loadTotalInvoices() async {
    final invoices = await DatabaseHelper.instance.getAllInvoices();
    setState(() {
      totalInvoices = invoices.length;
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          // First Row - Statistics Card
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16.0),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primaryContainer,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withAlpha(26),
                  spreadRadius: 1,
                  blurRadius: 5,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildStatColumn(
                  context,
                  'Total Items',
                  totalItems.toString(),
                  Icons.inventory,
                  Colors.blue,
                ),
                Container(
                  height: 50,
                  width: 1,
                  color: Colors.grey.withOpacity(0.3),
                ),
                _buildStatColumn(
                  context,
                  'Total Customers',
                  totalCustomers.toString(),
                  Icons.people,
                  Colors.green,
                ),
                Container(
                  height: 50,
                  width: 1,
                  color: Colors.grey.withOpacity(0.3),
                ),
                _buildStatColumn(
                  context,
                  'Total Invoices',
                  totalInvoices.toString(),
                  Icons.receipt_long,
                  Colors.orange,
                ),
              ],
            ),
          ),

          const SizedBox(height: 24),

          // Second Row - Profit Overview Card
          Container(
            width: double.infinity,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withAlpha(26),
                  spreadRadius: 1,
                  blurRadius: 5,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Text(
                    'Profit Overview',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                ),
                TabBar(
                  controller: _tabController,
                  labelColor: Theme.of(context).primaryColor,
                  unselectedLabelColor: Colors.grey,
                  tabs: const [
                    Tab(text: 'Daily'),
                    Tab(text: 'Weekly'),
                    Tab(text: 'Monthly'),
                    Tab(text: 'Yearly'),
                  ],
                ),
                SizedBox(
                  height: 200,
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      _buildProfitTab(
                        totalSales: '₹12,500',
                        totalCost: '₹8,200',
                        totalProfit: '₹4,300',
                      ),
                      _buildProfitTab(
                        totalSales: '₹85,000',
                        totalCost: '₹52,000',
                        totalProfit: '₹33,000',
                      ),
                      _buildProfitTab(
                        totalSales: '₹320,000',
                        totalCost: '₹195,000',
                        totalProfit: '₹125,000',
                      ),
                      _buildProfitTab(
                        totalSales: '₹3,850,000',
                        totalCost: '₹2,250,000',
                        totalProfit: '₹1,600,000',
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProfitTab({
    required String totalSales,
    required String totalCost,
    required String totalProfit,
  }) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildProfitItem(
            'Total Sales',
            totalSales,
            Icons.trending_up,
            Colors.green,
          ),
          _buildProfitItem(
            'Total Cost',
            totalCost,
            Icons.trending_down,
            Colors.red,
          ),
          _buildProfitItem(
            'Total Profit',
            totalProfit,
            Icons.account_balance_wallet,
            Colors.blue,
          ),
        ],
      ),
    );
  }

  Widget _buildProfitItem(
    String title,
    String value,
    IconData icon,
    Color color,
  ) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          icon,
          color: color,
          size: 32,
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          title,
          style: TextStyle(
            fontSize: 14,
            color: Colors.grey.shade600,
          ),
        ),
      ],
    );
  }

  Widget _buildStatColumn(
    BuildContext context,
    String title,
    String value,
    IconData icon,
    Color iconColor,
  ) {
    return GestureDetector(
      onTap: () async {
        if (title == 'Total Items') {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const ItemsPage()),
          );
          _loadTotalItems();
        } else if (title == 'Total Customers') {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const CustomersPage()),
          );
          _loadTotalCustomers();
        } else if (title == 'Total Invoices') {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const InvoicesPage()),
          );
          _loadTotalInvoices();
        }
      },
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            color: iconColor,
            size: 28,
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            title,
            style: TextStyle(
              fontSize: 12,
              color: Colors.grey.shade700,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
