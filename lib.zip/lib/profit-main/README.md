# profit
 Calculate
 https://dipesh1997.github.io/profit/
